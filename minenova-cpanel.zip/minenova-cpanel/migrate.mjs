import { readFileSync, readdirSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";
import pg from "pg";

const { Client } = pg;
const __dirname = dirname(fileURLToPath(import.meta.url));

const client = new Client({ connectionString: process.env.DATABASE_URL });
await client.connect();

// Create migrations tracking table
await client.query(`
  CREATE TABLE IF NOT EXISTS drizzle_migrations (
    id serial PRIMARY KEY,
    tag text NOT NULL UNIQUE,
    applied_at timestamptz DEFAULT now()
  )
`);

const migDir = join(__dirname, "migrations");
const files = readdirSync(migDir)
  .filter(f => f.endsWith(".sql"))
  .sort();

for (const file of files) {
  const tag = file.replace(".sql", "");
  const { rows } = await client.query("SELECT id FROM drizzle_migrations WHERE tag=$1", [tag]);
  if (rows.length > 0) { console.log(`[skip] ${tag}`); continue; }

  const sql = readFileSync(join(migDir, file), "utf8");
  // Split on drizzle statement-breakpoint comments
  const statements = sql.split(/--> statement-breakpoint/).map(s => s.trim()).filter(Boolean);
  for (const stmt of statements) await client.query(stmt);

  await client.query("INSERT INTO drizzle_migrations (tag) VALUES ($1)", [tag]);
  console.log(`[ok]   ${tag}`);
}

await client.end();
console.log("Migrations complete.");
