MineNova — cPanel Deployment Guide
===================================

REQUIREMENTS
------------
- cPanel with Node.js Selector (Node 20+)
- PostgreSQL database
- Object Storage (for profile pictures / support images) — optional

QUICK SETUP
-----------
1. Create a PostgreSQL database in cPanel → PostgreSQL Databases
2. Upload and extract this zip into your cPanel home directory (e.g. ~/minenova/)
3. In cPanel → Node.js Selector:
   - Create application pointing to ~/minenova/
   - Set startup file: dist/index.mjs
   - Node.js version: 20 or higher
4. Set environment variables in cPanel → Node.js Selector → Environment Variables:
   DATABASE_URL=postgresql://user:pass@localhost:5432/dbname
   SESSION_SECRET=<long random string>
   PORT=<assigned by cPanel automatically>
5. In cPanel → Node.js Selector → Run NPM Script: run "migrate"
   (or SSH: cd ~/minenova && node migrate.mjs)
6. Restart the Node.js app
7. Visit your domain — admin panel at /admin

NGINX / APACHE REVERSE PROXY
-----------------------------
cPanel typically auto-configures the proxy from your domain to the Node.js port.
If not, add to .htaccess in public_html:

  RewriteEngine On
  RewriteRule ^(.*)$ http://localhost:PORT/$1 [P,L]

UPDATING
--------
1. Stop the Node.js app
2. Replace the dist/ folder with new build
3. Run migrations: node migrate.mjs
4. Restart the app
