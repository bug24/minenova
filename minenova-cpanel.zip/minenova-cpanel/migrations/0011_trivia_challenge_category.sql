ALTER TABLE "trivia_challenges" ADD COLUMN IF NOT EXISTS "category" text NOT NULL DEFAULT 'All';
