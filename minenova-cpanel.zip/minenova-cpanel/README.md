# MineNova — cPanel Deployment Guide

MineNova is a full-stack gamified crypto-mining web app built with:
- **Backend**: Node.js / Express 5 (ESM, fully bundled)
- **Frontend**: React 18 + Vite (pre-built static files)
- **Database**: PostgreSQL (via Drizzle ORM)

---

## Package Contents

```
minenova-cpanel/
├── README.md                   ← You are here
└── app/
    ├── server.mjs              ← Bundled Node.js API server (entry point)
    ├── pino-worker.mjs         ← Logger worker (required, must sit alongside server.mjs)
    ├── pino-file.mjs           ← Logger worker (required)
    ├── pino-pretty.mjs         ← Logger worker (required)
    ├── thread-stream-worker.mjs← Logger worker (required)
    ├── package.json            ← Only runtime deps that need npm install
    ├── .env.example            ← Environment variable template → copy to .env
    ├── public/                 ← Pre-built React frontend (upload to public_html)
    │   ├── index.html
    │   ├── assets/
    │   ├── .htaccess           ← Apache rewrite rules (SPA routing + API proxy)
    │   └── ...
    └── migrations/             ← PostgreSQL SQL migration files (run in order)
        ├── 0000_referral_upgrade_rewards.sql
        ├── 0001_upgrades_hash_rate_columns.sql
        ├── 0002_messy_viper.sql
        ├── 0003_jittery_plazm.sql
        └── 0004_crazy_next_avengers.sql
```

---

## Requirements

| Requirement | Notes |
|---|---|
| **Node.js** | v20 or later (LTS recommended) |
| **PostgreSQL** | v14+ — **not MySQL**. Most shared cPanel hosts use MySQL only. Use a VPS with cPanel, CloudLinux EasyApache + PostgreSQL addon, or a managed PostgreSQL service (Neon, Supabase, Aiven, etc.). |
| **Apache mod_proxy** | Required for the `.htaccess` API proxy. Usually enabled on cPanel. |
| **Apache mod_rewrite** | Required for SPA routing. Enabled by default on virtually all cPanel hosts. |

---

## Step 1 — Set Up PostgreSQL

### Option A: cPanel with PostgreSQL addon
1. In cPanel → **PostgreSQL Databases**
2. Create a new database (e.g., `minenova`)
3. Create a database user with a strong password
4. Grant all privileges to that user on the database
5. Your connection string will be: `postgresql://USER:PASSWORD@localhost:5432/minenova`

### Option B: External managed PostgreSQL (Neon, Supabase, Aiven, etc.)
1. Create a free PostgreSQL instance on [neon.tech](https://neon.tech) or [supabase.com](https://supabase.com)
2. Copy the connection string from the dashboard
3. Use it as your `DATABASE_URL`

### Run database migrations
Connect to your PostgreSQL database and run each migration file **in order**:

```bash
# Using psql CLI (replace with your connection details)
psql "postgresql://USER:PASSWORD@host:5432/minenova" -f app/migrations/0000_referral_upgrade_rewards.sql
psql "postgresql://USER:PASSWORD@host:5432/minenova" -f app/migrations/0001_upgrades_hash_rate_columns.sql
psql "postgresql://USER:PASSWORD@host:5432/minenova" -f app/migrations/0002_messy_viper.sql
psql "postgresql://USER:PASSWORD@host:5432/minenova" -f app/migrations/0003_jittery_plazm.sql
psql "postgresql://USER:PASSWORD@host:5432/minenova" -f app/migrations/0004_crazy_next_avengers.sql
```

Or paste them in your PostgreSQL web client (phpPgAdmin, Adminer, Supabase SQL editor, etc.).

> **Note:** Migrations are additive and safe to re-run — they use `IF NOT EXISTS` guards.

---

## Step 2 — Generate VAPID Keys (for Push Notifications)

Push notifications are optional. If you want them, generate a VAPID key pair:

```bash
# Run this from any machine with Node.js installed
npx web-push generate-vapid-keys
```

Copy the output `Public Key` and `Private Key` into your `.env` file.

---

## Step 3 — Upload the Node.js App to cPanel

### 3a. Upload app files

1. In **cPanel File Manager** (or via SFTP), create a directory **outside** `public_html` — e.g.:
   ```
   /home/yourusername/minenova-app/
   ```
2. Upload everything from the `app/` folder into `/home/yourusername/minenova-app/`:
   - `server.mjs`
   - `pino-worker.mjs`
   - `pino-file.mjs`
   - `pino-pretty.mjs`
   - `thread-stream-worker.mjs`
   - `package.json`
   - `.env.example` → **rename to `.env`** and fill in your values

### 3b. Install dependencies

SSH into your server and run:

```bash
cd /home/yourusername/minenova-app
npm install --omit=dev
```

This installs `nodemailer` (the only runtime dependency not bundled into `server.mjs`).

### 3c. Configure the Node.js app in cPanel

1. In cPanel → **Setup Node.js App**
2. Click **Create Application**
3. Fill in:

   | Field | Value |
   |---|---|
   | Node.js version | 20.x (or latest LTS) |
   | Application mode | Production |
   | Application root | `/home/yourusername/minenova-app` |
   | Application URL | Your domain (e.g., `yourdomain.com`) |
   | Application startup file | `server.mjs` |

4. Click **Create** to save

### 3d. Set environment variables

In the same **Setup Node.js App** interface, add each variable from your `.env` file:

| Variable | Example Value | Notes |
|---|---|---|
| `DATABASE_URL` | `postgresql://user:pass@host:5432/minenova` | Your PostgreSQL connection string |
| `PORT` | *(set automatically by cPanel)* | Do not override — cPanel sets this |
| `NODE_ENV` | `production` | Must be exactly `production` |
| `SESSION_SECRET` | `a-long-random-string` | Used to hash passwords — keep secret |
| `ADMIN_SECRET` | `your-admin-password` | Initial admin panel password |
| `VAPID_PUBLIC_KEY` | *(from step 2)* | Leave empty to disable push notifications |
| `VAPID_PRIVATE_KEY` | *(from step 2)* | Leave empty to disable push notifications |
| `VAPID_SUBJECT` | `mailto:admin@yourdomain.com` | Your contact email for VAPID |
| `ADMIN_USER_ID` | `1` | User ID to receive admin push notifications |
| `LOG_LEVEL` | `info` | Options: trace, debug, info, warn, error |
| `MINENOVA_DIST` | `/home/yourusername/public_html/app/public` | Path to your uploaded frontend static files |

> **Important:** The `MINENOVA_DIST` variable tells the server where to find the React frontend. Set it to the absolute path of where you upload the `public/` folder in Step 4.

---

## Step 4 — Upload the Frontend to public_html

1. In **File Manager**, navigate to `/home/yourusername/public_html/`
2. Upload everything from `app/public/` — this includes:
   - `index.html`
   - `assets/` folder
   - `manifest.json`, `sw.js`, `favicon*.png`, `logo.png`, etc.
   - `.htaccess` ← **important — must be uploaded too**
3. Open `.htaccess` in the editor and **replace `%PORT%`** with the port cPanel assigned to your Node.js app (visible in the Setup Node.js App interface)

   Example — if cPanel assigned port `12345`:
   ```apache
   RewriteRule ^api/(.*)$ http://127.0.0.1:12345/api/$1 [P,L]
   ```

---

## Step 5 — Start the App

1. In cPanel → **Setup Node.js App** → find your MineNova app
2. Click **Run NPM Install** (if not already done)
3. Click **Start App**
4. Visit your domain — the app should be live

---

## Step 6 — First Login

1. Go to `https://yourdomain.com` and register an account
2. The **first user** registered (user ID 1) automatically becomes the admin
3. Access the admin panel at `https://yourdomain.com` → log in → tap the **Admin** tab

---

## Troubleshooting

### App won't start
- Check the **error log** in cPanel → Setup Node.js App → your app → **Error Log**
- Ensure `DATABASE_URL` is correct and the database accepts connections
- Ensure all 5 `.mjs` worker files are in the same directory as `server.mjs`
- Ensure `npm install` was run in the app directory

### API returns 502 / Bad Gateway
- The `.htaccess` `%PORT%` was not replaced — update it with the actual cPanel-assigned port
- Ensure `mod_proxy` and `mod_proxy_http` are enabled (ask your host)

### Push notifications not working
- Check `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, and `VAPID_SUBJECT` are all set
- The site must be served over **HTTPS** for push notifications to work

### Database connection errors
- Verify `DATABASE_URL` format: `postgresql://user:pass@host:5432/dbname`
- Ensure all 5 migration files were run and completed without errors
- If using an external database, ensure your server's IP is in the firewall allowlist

### "React app not built" error
- Ensure `MINENOVA_DIST` points to the absolute path of the `public/` directory
- Verify `index.html` exists at that path

---

## Security Checklist (Before Going Live)

- [ ] Change `SESSION_SECRET` to a long random string (32+ characters)
- [ ] Change `ADMIN_SECRET` to a strong password
- [ ] Generate unique VAPID keys — do not use keys from another installation
- [ ] Enable HTTPS on your domain (cPanel → SSL/TLS → Let's Encrypt)
- [ ] Review `LOG_LEVEL` — use `warn` or `error` in production to reduce disk usage

---

## File Size Reference

| File | Size |
|---|---|
| `server.mjs` (bundled API) | ~2.8 MB |
| `public/assets/index.js` (bundled React) | ~927 KB (262 KB gzip) |
| `public/assets/index.css` (bundled CSS) | ~144 KB (22 KB gzip) |

---

*Generated from MineNova monorepo — pnpm workspace, Express 5, React 18, Drizzle ORM, PostgreSQL.*
